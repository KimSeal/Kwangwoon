package com.example.loginsqlite;

public class ListViewAdapterData {
    //to save id, username, email to print list
    private String num;
    private String name;
    private String email;
    public void setNum(String num){this.num=num;}
    public void setName(String name){this.name = name;}
    public void setEmail(String email){this.email=email;}
    public String getNum(){return this.num;}
    public String getName(){return this.name;}
    public String getEmail(){return this.email;}
}
