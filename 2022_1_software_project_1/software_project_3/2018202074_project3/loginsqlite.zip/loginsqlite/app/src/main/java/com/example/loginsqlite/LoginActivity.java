package com.example.loginsqlite;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class LoginActivity extends AppCompatActivity {
    EditText username, password;
    Button btnlogin, btnlogin2, btnlogin3;
    DBHelper DB;
    //variable to control view
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        username = (EditText) findViewById(R.id.username1);
        password = (EditText) findViewById(R.id.password1);
        btnlogin = (Button) findViewById(R.id.btnsignin1);
        btnlogin2 = (Button) findViewById(R.id.btnsignin2);
        btnlogin3 = (Button) findViewById(R.id.btnsignin3);
        //put view information in variable
        DB = new DBHelper(this);
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //when click login button
                String user = username.getText().toString();
                String pass = password.getText().toString();
                if(user.equals("admin") && pass.equals("1")){
                    //when admin login execute
                    Intent intent  = new Intent(getApplicationContext(), AdminActivity.class);
                    intent.putExtra("deletename","admin");
                    //user dont choose delete data yet
                    startActivity(intent);
                    //start admin activity
                }
                else if(user.equals("")||pass.equals("")||user.equals("admin"))
                    //error about blank input or admin login
                    Toast.makeText(LoginActivity.this, "Wrong input", Toast.LENGTH_SHORT).show();
                else{
                    Boolean checkuserpass = DB.checkusernamepassword(user, pass);
                    if(checkuserpass==true){
                        //login input is right
                        Toast.makeText(LoginActivity.this, "Sign in successfull", Toast.LENGTH_SHORT).show();
                        Intent intent  = new Intent(getApplicationContext(), HomeActivity.class);
                        intent.putExtra("findname",user);
                        startActivity(intent);
                        //go to Home activity with login information
                    }
                    else{
                        Toast.makeText(LoginActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                        //when login fail
                    }
                }
            }
        });
        btnlogin2.setOnClickListener(new View.OnClickListener() {
            //when click button to make id
            @Override
            public void onClick(View view) {
                Intent intent  = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                //go to Make Id page
            }
        });
        btnlogin3.setOnClickListener(new View.OnClickListener() {
            //when click button to find password
            @Override
            public void onClick(View view) {
                Intent intent  = new Intent(getApplicationContext(), PassActivity.class);
                startActivity(intent);
                //move to Find password page
            }
        });
    }
}
