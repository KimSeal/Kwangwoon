package com.example.loginsqlite;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText username, password, idinput, yearinput, monthinput, dayinput, emailinput;
    Button signup, signin, signdup;
    DBHelper DB;
    Boolean Idchk;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Idchk=false;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);

        idinput = (EditText) findViewById(R.id.idinput);
        yearinput = (EditText) findViewById(R.id.yearinput);
        monthinput = (EditText) findViewById(R.id.monthinput);
        dayinput = (EditText) findViewById(R.id.dayinput);
        emailinput = (EditText) findViewById(R.id.emailinput);
        //about write object
        signdup = (Button) findViewById(R.id.dupchk);
        signup = (Button) findViewById(R.id.btnsignup);
        //button to check dup id and sign up
        DB = new DBHelper(this);

        idinput.addTextChangedListener(new TextWatcher() {
            //when user change about id value
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                Idchk=false;
                //to user check about dup id later again
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        signdup.setOnClickListener(new View.OnClickListener() {
            //when click this button to check dup Id
            @Override
            public void onClick(View view) {
                String user = idinput.getText().toString();
                if(true){
                    Boolean checkuser = DB.checkusername(user);
                    if(!user.equals("")) {
                        //input is not blank
                        if (checkuser == false) {
                            //if somebody use that Id
                            Toast.makeText(MainActivity.this, "사용가능한 ID입니다.", Toast.LENGTH_SHORT).show();
                            Idchk = true;
                        } else {
                            //if nobody use that Id
                            Toast.makeText(MainActivity.this, "사용중인 ID입니다.", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(MainActivity.this, "입력을 하셔야 합니다.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        signup.setOnClickListener(new View.OnClickListener() {
            //after write finish, user try to sign up
            @Override
            public void onClick(View view) {
                String user = idinput.getText().toString();
                String pass = password.getText().toString();
                String userid = username.getText().toString();
                String year = yearinput.getText().toString();
                String month = monthinput.getText().toString();
                String day = dayinput.getText().toString();
                String email = emailinput.getText().toString();
                //take user input datas
                if(user.equals("")||pass.equals(""))
                    Toast.makeText(MainActivity.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();
                    //when user dont write Id and password
                else{
                    if(true){
                        Boolean checkuser = DB.checkusername(user);
                        if(checkuser==false && Idchk==true){
                            //when dup Id check is finished
                            Boolean insert = DB.insertData(user, pass, userid, year, month, day, email);
                            //insert user data in sqlite
                            if(insert==true){
                                //when insert success
                                Toast.makeText(MainActivity.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                                startActivity(intent);
                                //go back to login activity
                            }else{
                                Toast.makeText(MainActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                                //when fail sign up
                            }
                        }
                        else{
                            Toast.makeText(MainActivity.this, "Dup ID check please", Toast.LENGTH_SHORT).show();
                        }
                    }
                } }
        });
    }
}