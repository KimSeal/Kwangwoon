package com.example.loginsqlite;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DBNAME = "Login.db";
    public DBHelper(Context context) {
        super(context, "Login.db", null, 1);
    }
    //data to make db table
    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        MyDB.execSQL("create Table users(username TEXT primary key, " +
                "password TEXT, idinput TEXT, yearinput TEXT, monthinput TEXT, dayinput TEXT, emailinput TEXT)");
        //make table to save data
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        MyDB.execSQL("drop Table if exists users");
        //dont make dup table
    }
    public Boolean updateData(String id, String name, String year, String month, String day, String email){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put("idinput",name);
        contentValues.put("yearinput",year);
        contentValues.put("monthinput",month);
        contentValues.put("dayinput",day);
        contentValues.put("emailinput", email);
        //make content value to update data in table
        db.update("users",contentValues,"username = ?",new String[]{id});
        //update content in table's element that have current id
        return true;
    }
    public Boolean deleteDate(String username){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        long result = MyDB.delete("users","username = ?",new String[] {username});
        //delete data that have input username
        if(result==-1){ return false;}
        else{ return true;}
        //to check successs
    }

    public Boolean insertData(String username, String password, String id, String year, String month, String day, String email) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        contentValues.put("idinput", id);
        contentValues.put("yearinput", year);
        contentValues.put("monthinput", month);
        contentValues.put("dayinput", day);
        contentValues.put("emailinput", email);
        //make content value to put data in table
        long result = MyDB.insert("users", null, contentValues);
        //insert content in table's element that have current id
        if (result == -1) return false;
        else
            return true;
    }

    public Boolean checkusername(String username) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[]{username});
        //take data that have input Id
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
        //check data exist, if no exist, return false to check error
    }

    public Boolean checkusernamepassword(String username, String password) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ? and password = ?", new String[]{username, password});
        //take data that have input Id and password
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
        //check data exist, if no exist, return false to check error
    }
    public Boolean findpassword(String username, String year, String month, String day, String email) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where idinput = ? and yearinput = ? and monthinput =?" +
                "and dayinput = ? and emailinput = ? ", new String[]{username, year,month,day,email});
        //find data that have input about name, year, month, day, email
        if(cursor.getCount()==0){
            return false;
        }
        return true;
        //check data exist, if no exist, return false to check error
    }

    public String passwordprint2(String username, String year, String month, String day, String email) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        String pass="unknown";
        //if cant find, return unknown
        Cursor cursor = MyDB.rawQuery("Select * from users where idinput = ? and yearinput = ? and monthinput =?" +
                "and dayinput = ? and emailinput = ? ", new String[]{username, year,month,day,email});
        while (cursor.moveToNext()) {
            if(username.equals(cursor.getString(2))){
                //take username if that data have imformation to find
                pass=cursor.getString(1);
                break;
            }
        }
        return pass;
    }
    public String passwordprint(String username) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        String pass="unknown";
        //if cant find, return unknown
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[]{username});
        while (cursor.moveToNext()) {
            if(username.equals(cursor.getString(0))){
                //take Id if that data have Id to find
                pass=cursor.getString(1);
                break;
            }
        }
        return pass;
    }
    public String idprint(String username) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        String pass="unknown";
        //if cant find, return unknown

        Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[]{username});
        while (cursor.moveToNext()) {
            if(username.equals(cursor.getString(0))){
                //find username use id
                pass=cursor.getString(2);
                break;
            }
        }
        return pass;
    }
    public String yearprint(String username) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        String pass="unknown";
        //if cant find, return unknown

        Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[]{username});
        while (cursor.moveToNext()) {
            //find year user id
            if(username.equals(cursor.getString(0))){
                pass=cursor.getString(3);
                break;
            }
        }
        return pass;
    }
    public String monthprint(String username) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        String pass="unknown";
        //if cant find, return unknown
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[]{username});
        while (cursor.moveToNext()) {
            //find Month user id
            if(username.equals(cursor.getString(0))){
                pass=cursor.getString(4);
                break;
            }
        }
        return pass;
    }
    public String dayprint(String username) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        String pass="unknown";
        //if cant find, return unknown
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[]{username});
        while (cursor.moveToNext()) {
            //find day user id
            if(username.equals(cursor.getString(0))){
                pass=cursor.getString(5);
                break;
            }
        }
        return pass;
    }
    public String emailprint(String username) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        String pass="unknown";
        //if cant find, return unknown
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[]{username});
        while (cursor.moveToNext()) {
            //find email use id
            if(username.equals(cursor.getString(0))){
                pass=cursor.getString(6);
                break;
            }
        }
        return pass;
    }
}