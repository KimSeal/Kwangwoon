package com.example.loginsqlite;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class PassActivity extends AppCompatActivity {
    EditText username, password, Year, Month, Day, Email;
    Button btnlogin, btnlogin2;
    DBHelper DB;
    //variable to take view data and sqlite data
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pass);
        //initalize this activity
        username = (EditText) findViewById(R.id.username1);
        Year = (EditText) findViewById(R.id.Year);
        Month = (EditText) findViewById(R.id.Month);
        Day = (EditText) findViewById(R.id.Day);
        Email = (EditText) findViewById(R.id.email);
        //connect view and this code
        btnlogin = (Button) findViewById(R.id.btnsignin1);
        btnlogin2 = (Button) findViewById(R.id.btnsignin2);
        //button variable
        DB = new DBHelper(this);
        btnlogin.setOnClickListener(new View.OnClickListener() {
            //when search button click
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String year = Year.getText().toString();
                String month = Month.getText().toString();
                String day = Day.getText().toString();
                String email = Email.getText().toString();
                //to take user input data
                if(user.equals("")||year.equals("")||month.equals("")||day.equals("")||email.equals(""))
                    //when empty input exist
                    Toast.makeText(PassActivity.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();
                else{
                    //find password using this information
                    Boolean password = DB.findpassword(user,year,month,day,email);
                    if(password){
                        String print=DB.passwordprint2(user,year,month,day,email);
                        Toast.makeText(PassActivity.this, print, Toast.LENGTH_SHORT).show();
                        //send toast message about password
                    }
                    else{
                        Toast.makeText(PassActivity.this, "wrong input", Toast.LENGTH_SHORT).show();
                        //when sqlite dont have data about that input
                    }
                }
            }
        });
        btnlogin2.setOnClickListener(new View.OnClickListener() {
            //user click this button to go login page
            @Override
            public void onClick(View view) {
                Intent intent  = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                //goto login page
            }
        });
    }
}
