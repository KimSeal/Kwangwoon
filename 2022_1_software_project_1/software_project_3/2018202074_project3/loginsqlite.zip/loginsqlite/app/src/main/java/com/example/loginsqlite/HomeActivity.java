package com.example.loginsqlite;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {
    TextView tv;
    EditText mEdit1, mEdit2, mEdit3, mEdit4, mEdit5, mEdit6;
    DBHelper DB;
    String tvstr;
    ImageButton but;
    //variable to print view

    @SuppressLint("Range")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        //activity intialize

        Intent intent = getIntent();
        String text = intent.getStringExtra("findname");
        //take Id to find data

        DB = new DBHelper(this);
        String pass=DB.passwordprint(text);
        String id=DB.idprint(text);
        String year=DB.yearprint(text);
        String month=DB.monthprint(text);
        String day=DB.dayprint(text);
        String email=DB.emailprint(text);
        //take every information about Id
        tvstr = id+"님의 정보";
        //make title format
        tv = (TextView) findViewById(R.id.titlename);
        tv.setText(tvstr);
        mEdit1 = (EditText) findViewById(R.id.stredit);
        mEdit1.setText(id);
        mEdit2 = (EditText) findViewById(R.id.strid);
        mEdit2.setText(text);
        mEdit3 = (EditText) findViewById(R.id.stryear);
        mEdit3.setText(year);
        mEdit4 = (EditText) findViewById(R.id.strmonth);
        mEdit4.setText(month);
        mEdit5 = (EditText) findViewById(R.id.strday);
        mEdit5.setText(day);
        mEdit6 = (EditText) findViewById(R.id.stremail);
        mEdit6.setText(email);
        //put data values in Edit text
        but = (ImageButton) findViewById(R.id.but);
        //button to exit & update
        but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id2 = mEdit1.getText().toString();
                String text2 = mEdit2.getText().toString();
                String year2 = mEdit3.getText().toString();
                String month2 = mEdit4.getText().toString();
                String day2 = mEdit5.getText().toString();
                String email2 = mEdit6.getText().toString();
                //variable to compare input change
                if(text.equals(text2)){
                    if(id2.equals(id) && year2.equals(year) &&
                            month2.equals(month) && day2.equals(day) && (email2.equals(email))){
                        //nothing change
                        Intent intent  = new Intent(getApplicationContext(), LoginActivity.class);
                        startActivity(intent);
                        //exit from home
                    }
                    else{
                        //something is changed
                        Toast.makeText(HomeActivity.this, "try update", Toast.LENGTH_SHORT).show();
                        Boolean insert = DB.updateData(text2, id2, year2, month2, day2, email2);
                        //update data
                        if(insert){
                            Intent intent  = new Intent(getApplicationContext(), LoginActivity.class);
                            startActivity(intent);
                            //exit from home
                        }
                        else{
                            Toast.makeText(HomeActivity.this, "insert error, try again", Toast.LENGTH_SHORT).show();
                        }

                    }
                }
                else{
                    //if Id changed(error)
                    Toast.makeText(HomeActivity.this, "DontchangeId", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
