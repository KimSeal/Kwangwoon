package com.example.loginsqlite;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class AdminActivity extends AppCompatActivity {

    ListView lvList;
    //listview to print all data
    ImageButton but, trash; //button to exit or delete
    DBHelper DB;            //to use SQLITE database
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        //make this activity

        Intent intent2 = getIntent();
        String delname = intent2.getStringExtra("deletename");
        //get data's id that will be deleted

        DB = new DBHelper(this);
        lvList = (ListView)findViewById(R.id.lv_list);
        but = (ImageButton)findViewById(R.id.but);
        trash = (ImageButton)findViewById(R.id.trash);
        //connect view and code
        but.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                //when click exit button, go home
            }
        });

        trash.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if(delname.equals("admin")){
                    Toast.makeText(AdminActivity.this, "선택하셔야 합니다.", Toast.LENGTH_SHORT).show();
                    //when user not choose anything, we cant delete
                }
                else{
                    //click trash button after user choose delete data
                    Toast.makeText(AdminActivity.this, "Delete success", Toast.LENGTH_SHORT).show();
                    Boolean insert = DB.deleteDate(delname);
                    Intent intent = new Intent(getApplicationContext(), AdminActivity.class);
                    intent.putExtra("deletename","admin");
                    startActivity(intent);
                    //delete data in sqlite, and restart this page to print new table
                }
            }
        });
        displayList();
    }
    //function to print list
    void displayList(){
        //take DBhelper to read DB
        DBHelper helper = new DBHelper(this);
        SQLiteDatabase database = helper.getReadableDatabase();

        //Cursor take sqlite table
        Cursor cursor = database.rawQuery("SELECT * FROM users",null);

        ListViewAdapter adapter = new ListViewAdapter();

        //read all of data in table(user cursor)
        while(cursor.moveToNext()){
            //take name, id, email in table
            adapter.addItemToList(cursor.getString(2),cursor.getString(0),cursor.getString(6));

        }

        //set listview's adapter= this adpater
        lvList.setAdapter(adapter);
    }

}
