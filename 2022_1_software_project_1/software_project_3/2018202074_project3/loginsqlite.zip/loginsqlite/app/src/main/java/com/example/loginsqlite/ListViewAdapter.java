package com.example.loginsqlite;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ListViewAdapter extends BaseAdapter {
    ArrayList<ListViewAdapterData> list = new ArrayList<ListViewAdapterData>();
    @Override
    public int getCount(){
        return list.size();
    }
    @Override
    public Object getItem(int i){
        return list.get(i);
    }

    @Override
    public long getItemId(int i){
        return i;
    }
    //function to give data
    public View getView(int i, View view, ViewGroup viewGroup){
        final Context context = viewGroup.getContext();
        if(view==null){
            LayoutInflater inflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.item_listview,viewGroup,false);
        }
        //initialize view to print list
        TextView tvNum = (TextView)view.findViewById(R.id.item_tv_num);
        TextView tvName = (TextView)view.findViewById(R.id.item_tv_name);
        TextView tvEmail = (TextView)view.findViewById(R.id.item_tv_email);
        RadioButton radio = (RadioButton)view.findViewById(R.id.radio);
        //take variables to set view
        ListViewAdapterData listdata = list.get(i);
        //take information
        radio.setText(listdata.getNum()+"/"+listdata.getName()+"/"+listdata.getEmail());
        //format to print sqlite data
        radio.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                //when click radio button
                Context context=view.getContext();
                Intent intent = new Intent(view.getContext(), AdminActivity.class);
                intent.putExtra("deletename",listdata.getName());
                //give radio's imformation and reset this activity
                context.startActivity(intent);
            }
        });

        return view;
        //return view to print list
    }
    public void addItemToList(String num, String name, String email){
        ListViewAdapterData listdata = new ListViewAdapterData();

        listdata.setNum(num);
        listdata.setName(name);
        listdata.setEmail(email);

        //make data that have 3 information and add that in list
        list.add(listdata);

    }
}
